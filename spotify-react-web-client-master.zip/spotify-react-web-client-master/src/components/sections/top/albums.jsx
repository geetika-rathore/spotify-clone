import React from 'react';

import Top from './generic';

const albums = props => <Top title="Albums" type="album" url="/me/albums" />;

export default albums;
